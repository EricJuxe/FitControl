package ClasesAuxiliares;

import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JPasswordField;

/**
 *
 * @author ericj
 */
public class PlaceholderPasswordField {
   public static void aplicarPlaceholder(JPasswordField campo, String placeholder) {
        // Color gris clarito para el placeholder
        Color colorPlaceholder = Color.GRAY;

        // Si el campo está vacío, se muestra el placeholder
        if (campo.getPassword().length == 0) {
            campo.setEchoChar((char) 0); // mostrar texto en claro
            campo.setText(placeholder);
            campo.setForeground(colorPlaceholder);
        }

        // Al obtener el foco
        campo.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                String texto = new String(campo.getPassword());
                if (texto.equals(placeholder)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                    campo.setEchoChar('•'); // caracter por defecto
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                String texto = new String(campo.getPassword());
                if (texto.isEmpty()) {
                    campo.setEchoChar((char) 0); // mostrar texto en claro
                    campo.setText(placeholder);
                    campo.setForeground(colorPlaceholder);
                }
            }
        });
    } 
}
