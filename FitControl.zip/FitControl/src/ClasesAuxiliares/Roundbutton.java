package ClasesAuxiliares;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;

public class Roundbutton {

    public static void aplicarRedondoAnimado(JButton boton, int radio) {
        boton.setBorder(new BordeRedondeado(radio));
        boton.setFocusPainted(false);
        boton.setContentAreaFilled(false);
        boton.setOpaque(false);

        // Sobrescribir el comportamiento de pintado
        boton.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
    @Override
    public void paint(Graphics g, JComponent c) {
        AbstractButton b = (AbstractButton) c;
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Fondo dinámico según estado
        if (b.getModel().isPressed()) {
            g2.setColor(b.getBackground().darker());
        } else if (b.getModel().isRollover()) {
            g2.setColor(b.getBackground().brighter());
        } else {
            g2.setColor(b.getBackground());
        }

        g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), radio, radio);
        g2.dispose();

        // Esto pinta el contenido como texto e ícono correctamente
        super.paint(g, c);
    }
});

    }

    // Borde redondeado (igual que antes)
    private static class BordeRedondeado implements Border {
        private final int radio;

        public BordeRedondeado(int radio) {
            this.radio = radio;
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(radio, radio, radio, radio);
        }

        @Override
        public boolean isBorderOpaque() {
            return false;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width - 1, height - 1, radio, radio);
        }
    }
}
