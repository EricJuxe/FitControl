package ClasesAuxiliares;

import com.mysql.conexion.DBconexion;
import java.awt.HeadlessException;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Tabla {

    private Connection con;
    private String name;
    private ArrayList<String> columns;

    // Constructor
    public Tabla(String name) {
        this.name = name;
        this.con = DBconexion.getConection();
        this.columns = asignarColumnas();
    }

    public String getName() {
        return name;
    }

    public ArrayList<String> getColumns() {
        return columns;
    }

    // Insertar registros dinámicamente
    public void add(ArrayList<String> campos) {
        int numeroColumnas = columns.size();
        String nombresColumnas = String.join(",", columns);
        StringBuilder signos = new StringBuilder("?");

        for (int i = 1; i < numeroColumnas; i++) {
            signos.append(",?");
        }

        String insertQuery = "INSERT INTO " + name + " (" + nombresColumnas + ") VALUES (" + signos + ")";

        try (PreparedStatement statement = con.prepareStatement(insertQuery)) {
            for (int i = 0; i < campos.size(); i++) {
                String campo = campos.get(i).isEmpty() ? null : campos.get(i);
                statement.setString(i + 1, campo);
            }

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Los datos se han insertado correctamente.");
            }

        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al insertar: " + e);
        }
    }

    // Eliminar registros dinámicamente (usando condiciones por campos)
    public void eliminar(ArrayList<String> campos) {
        StringBuilder sql = new StringBuilder("DELETE FROM " + name + " WHERE " + columns.get(0) + " = '" + campos.get(0) + "'");

        for (int i = 1; i < columns.size(); i++) {
            if (campos.get(i) != null && !campos.get(i).isEmpty()) {
                sql.append(" AND ").append(columns.get(i)).append(" = '").append(campos.get(i)).append("'");
            }
        }

        try (PreparedStatement eliminar = con.prepareStatement(sql.toString())) {
            eliminar.executeUpdate();
            JOptionPane.showMessageDialog(null, "Se ha eliminado con éxito.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar: " + e);
        }
    }

    // Actualizar registros dinámicamente
    public void update(ArrayList<String> campos, ArrayList<String> cambios) {
        StringBuilder sql1 = new StringBuilder("UPDATE " + name + " SET ");
        for (int i = 0; i < cambios.size(); i++) {
            if (cambios.get(i) != null && !cambios.get(i).isEmpty()) {
                sql1.append(columns.get(i)).append(" = '").append(cambios.get(i)).append("'");
                if (i < cambios.size() - 1) {
                    sql1.append(", ");
                }
            }
        }

        StringBuilder sql2 = new StringBuilder(" WHERE ");
        for (int i = 0; i < campos.size(); i++) {
            if (campos.get(i) != null && !campos.get(i).isEmpty()) {
                sql2.append(columns.get(i)).append(" = '").append(campos.get(i)).append("'");
                if (i < campos.size() - 1) {
                    sql2.append(" AND ");
                }
            }
        }

        String sql = sql1.toString() + sql2.toString();

        try (PreparedStatement actualizar = con.prepareStatement(sql)) {
            actualizar.executeUpdate();
            JOptionPane.showMessageDialog(null, "Se actualizó con éxito.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar: " + e);
        }
    }

    // Consultar toda la tabla
    public ArrayList<ArrayList<String>> consultar() {
        ArrayList<ArrayList<String>> filas = new ArrayList<>();
        String sql = "SELECT * FROM " + name;

        try (Statement leer = con.createStatement();
             ResultSet resultado = leer.executeQuery(sql)) {

            ResultSetMetaData metaData = resultado.getMetaData();
            int columnas = metaData.getColumnCount();

            while (resultado.next()) {
                ArrayList<String> fila = new ArrayList<>();
                for (int i = 1; i <= columnas; i++) {
                    fila.add(resultado.getString(i));
                }
                filas.add(fila);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar: " + e);
        }

        return filas;
    }

    // Obtener nombres de columnas automáticamente
    private ArrayList<String> asignarColumnas() {
        ArrayList<String> c = new ArrayList<>();
        String sql = "SELECT * FROM " + name + " WHERE 1=0";

        try (Statement leer = con.createStatement();
             ResultSet resultado = leer.executeQuery(sql)) {

            ResultSetMetaData metaData = resultado.getMetaData();
            for (int i = 1; i <= metaData.getColumnCount(); i++) {
                c.add(metaData.getColumnName(i));
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener columnas: " + e);
        }

        return c;
    }
}
