package ClasesAuxiliares;

import org.mindrot.jbcrypt.BCrypt;
import java.util.Scanner;

public class GeneradorHash {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingresa la contraseña a encriptar: ");
        String contraseña = scanner.nextLine();

        // Generar el hash con BCrypt
        String hash = BCrypt.hashpw(contraseña, BCrypt.gensalt());

        
        System.out.println(hash);

        scanner.close();
    }
    
}
