
package main;

import FitControl.Login;
import FitControl.MenuPrincipal;

/**
 *
 * @author ericj
 */
public class Main {
    public static void main(String [] args){
        System.out.println("Hola mundo");
       Login l= new Login();
       //MenuPrincipal m= new MenuPrincipal();
    }
}
