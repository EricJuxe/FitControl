/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package FitControl;

import ClasesAuxiliares.Roundbutton;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.mysql.conexion.Conexion;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JLabel;

/**
 *
 * @author ericj
 */
public class Clases extends javax.swing.JPanel {

    /**
     * Creates new form Clases
     */
    // Lista para guardar los IDs de las clases en el mismo orden que el ComboBox
private java.util.List<Integer> idsClases = new java.util.ArrayList<>();

    public Clases() {
        initComponents();
        mostrarEntrenadores();
        mostrarClases();
        mostrarClientes();
        llenarComboClases();
        

    }
// Al seleccionar una clase en el JComboBox (por ejemplo, comboClases):


    private void mostrarEntrenadores() {
        try {
            Conexion connect = Conexion.getInstance();
            Connection con = connect.getConnection();

            String sql = "SELECT id, nombre, apellido, especialidad, correo, telefono FROM entrenador";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet resultado = pst.executeQuery();

            DefaultTableModel modelo = new DefaultTableModel();
            modelo.addColumn("ID");
            modelo.addColumn("Nombre");
            modelo.addColumn("Apellido");
            modelo.addColumn("Especialidad");
            modelo.addColumn("Correo");
            modelo.addColumn("Teléfono");

            while (resultado.next()) {
                Object[] fila = {
                    resultado.getString("id"),
                    resultado.getString("nombre"),
                    resultado.getString("apellido"),
                    resultado.getString("especialidad"),
                    resultado.getString("correo"),
                    resultado.getString("telefono")
                };
                modelo.addRow(fila);
            }

            jTable1.setModel(modelo);

            resultado.close();
            pst.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar entrenadores: " + e.getMessage());
        }
    }

    private void mostrarClientes() {
    try {
        Conexion connect = Conexion.getInstance();
        Connection con = connect.getConnection();

        // Solo selecciona los clientes activos
        String sql = "SELECT id, nombre, apellido, correo, telefono, fecha_registro FROM cliente WHERE estado = 'activo'";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet resultado = pst.executeQuery();

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido");
        modelo.addColumn("Correo");
        modelo.addColumn("Teléfono");
        modelo.addColumn("Fecha Registro");

        while (resultado.next()) {
            Object[] fila = {
                resultado.getString("id"),
                resultado.getString("nombre"),
                resultado.getString("apellido"),
                resultado.getString("correo"),
                resultado.getString("telefono"),
                resultado.getString("fecha_registro")
            };
            modelo.addRow(fila);
        }

        jTable2.setModel(modelo);
        jTable2.setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        resultado.close();
        pst.close();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar clientes: " + e.getMessage());
    }
}


    private void mostrarClases() {
        try {
            Conexion connect = Conexion.getInstance();
            Connection con = connect.getConnection();

            // Trae datos de la clase y el entrenador asociado
            String sql = "SELECT clase.id, clase.nombre, clase.horario, entrenador.nombre AS entrenador_nombre, entrenador.apellido AS entrenador_apellido "
                    + "FROM clase "
                    + "JOIN entrenador ON clase.id_entrenador = entrenador.id";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet resultado = pst.executeQuery();

            // Modelo de la tabla
            DefaultTableModel modelo = new DefaultTableModel();
            modelo.addColumn("ID");
            modelo.addColumn("Nombre de Clase");
            modelo.addColumn("Horario");
            modelo.addColumn("Entrenador");

            // Llena el modelo con los datos obtenidos
            while (resultado.next()) {
                Object[] fila = {
                    resultado.getString("id"),
                    resultado.getString("nombre"),
                    resultado.getString("horario"),
                    resultado.getString("entrenador_nombre") + " " + resultado.getString("entrenador_apellido")
                };
                modelo.addRow(fila);
            }

            jTable3.setModel(modelo);

            resultado.close();
            pst.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar las clases: " + e.getMessage());
        }
    }
    
    private void llenarComboClases() {
    idsClases.clear(); // Limpia la lista antes de llenarla de nuevo
    DefaultComboBoxModel<String> modeloCombo = new DefaultComboBoxModel<>();

    try {
        Conexion connect = Conexion.getInstance();
        Connection con = connect.getConnection();
        String sql = "SELECT id, nombre FROM clase";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            idsClases.add(rs.getInt("id"));
            modeloCombo.addElement(rs.getString("nombre"));
        }
        rs.close();
        pst.close();
        comboClases.setModel(modeloCombo);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar clases: " + e.getMessage());
    }
}

    private void mostrarClientesDeClase(int idClase) {
    try {
        Conexion connect = Conexion.getInstance();
        Connection con = connect.getConnection();

        String sql = "SELECT cliente.id, cliente.nombre, cliente.apellido, cliente.correo, cliente.telefono " +
                     "FROM clase_cliente " +
                     "JOIN cliente ON clase_cliente.id_cliente = cliente.id " +
                     "WHERE clase_cliente.id_clase = ?";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setInt(1, idClase);
        ResultSet resultado = pst.executeQuery();

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido");
        modelo.addColumn("Correo");
        modelo.addColumn("Teléfono");

        while (resultado.next()) {
            Object[] fila = {
                resultado.getString("id"),
                resultado.getString("nombre"),
                resultado.getString("apellido"),
                resultado.getString("correo"),
                resultado.getString("telefono")
            };
            modelo.addRow(fila);
        }

        jTableParticipantes.setModel(modelo);

        resultado.close();
        pst.close();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar clientes: " + e.getMessage());
    }
}

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        comboClases = new javax.swing.JComboBox<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTableParticipantes = new javax.swing.JTable();

        setBackground(new java.awt.Color(204, 204, 204));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setText("Entrenadores");

        jButton1.setText("Nuevo entrenador");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Borrar entrenador");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(jTable3);

        jLabel2.setText("Miembros");

        jLabel3.setText("Clases");

        jButton3.setText("Nueva clase");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Borrar calse");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Asignar clase a clientes");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        comboClases.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboClases.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                comboClasesMouseClicked(evt);
            }
        });
        comboClases.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboClasesActionPerformed(evt);
            }
        });

        jTableParticipantes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane4.setViewportView(jTableParticipantes);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jButton2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(45, 45, 45)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jButton3)
                            .addComponent(jButton4))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jButton5)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 462, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comboClases, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1)
                            .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jButton2))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton4))))
                    .addComponent(jButton5))
                .addGap(57, 57, 57)
                .addComponent(comboClases, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(109, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // Crear campos para el formulario
        JTextField nombreField = new JTextField();
        JTextField apellidoField = new JTextField();
        JTextField especialidadField = new JTextField();
        JTextField correoField = new JTextField();
        JTextField telefonoField = new JTextField();

        // Panel para organizar los campos
        JPanel panel = new JPanel(new java.awt.GridLayout(0, 1));
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Apellido:"));
        panel.add(apellidoField);
        panel.add(new JLabel("Especialidad:"));
        panel.add(especialidadField);
        panel.add(new JLabel("Correo:"));
        panel.add(correoField);
        panel.add(new JLabel("Teléfono:"));
        panel.add(telefonoField);

        int result = JOptionPane.showConfirmDialog(
                this, panel, "Registrar nuevo entrenador", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            try {
                // Obtener los valores
                String nombre = nombreField.getText();
                String apellido = apellidoField.getText();
                String especialidad = especialidadField.getText();
                String correo = correoField.getText();
                String telefono = telefonoField.getText();

                // Validación básica
                if (nombre.isEmpty() || apellido.isEmpty() || especialidad.isEmpty() || correo.isEmpty() || telefono.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Debes llenar todos los campos.");
                    return;
                }

                Conexion connect = Conexion.getInstance();
                Connection con = connect.getConnection();

                String sql = "INSERT INTO entrenador (nombre, apellido, especialidad, correo, telefono) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement pst = con.prepareStatement(sql);

                pst.setString(1, nombre);
                pst.setString(2, apellido);
                pst.setString(3, especialidad);
                pst.setString(4, correo);
                pst.setString(5, telefono);

                int filas = pst.executeUpdate();

                if (filas > 0) {
                    JOptionPane.showMessageDialog(this, "Entrenador registrado correctamente.");
                    mostrarEntrenadores(); // Refresca la tabla si tienes este método
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo registrar el entrenador.");
                }
                pst.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al registrar entrenador: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int fila = jTable1.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un entrenador para eliminar.");
            return;
        }

        // Obtén los datos del entrenador seleccionado (ajusta el índice si tu tabla cambia de orden)
        String id = jTable1.getValueAt(fila, 0).toString();
        String nombre = jTable1.getValueAt(fila, 1).toString();
        String apellido = jTable1.getValueAt(fila, 2).toString();
        String especialidad = jTable1.getValueAt(fila, 3).toString();
        String correo = jTable1.getValueAt(fila, 4).toString();
        String telefono = jTable1.getValueAt(fila, 5).toString();

        String mensaje = "¿Estás seguro de eliminar al siguiente entrenador?\n\n"
                + "ID: " + id
                + "\nNombre: " + nombre
                + "\nApellido: " + apellido
                + "\nEspecialidad: " + especialidad
                + "\nCorreo: " + correo
                + "\nTeléfono: " + telefono;

        int opcion = JOptionPane.showConfirmDialog(this, mensaje, "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

        if (opcion == JOptionPane.YES_OPTION) {
            try {
                Conexion connect = Conexion.getInstance();
                Connection con = connect.getConnection();

                String sql = "DELETE FROM entrenador WHERE id = ?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, id);

                int filas = pst.executeUpdate();

                if (filas > 0) {
                    JOptionPane.showMessageDialog(this, "Entrenador eliminado correctamente.");
                    mostrarEntrenadores(); // Refresca la tabla si tienes este método
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo eliminar el entrenador.");
                }
                pst.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al eliminar entrenador: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            // 1. Obtener lista de entrenadores de la base
            Conexion connect = Conexion.getInstance();
            Connection con = connect.getConnection();

            // Lista de entrenadores para el JComboBox
            java.util.List<Integer> idsEntrenadores = new java.util.ArrayList<>();
            javax.swing.DefaultComboBoxModel<String> modeloEntrenadores = new javax.swing.DefaultComboBoxModel<>();

            String sql = "SELECT id, nombre, apellido FROM entrenador";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                idsEntrenadores.add(rs.getInt("id"));
                modeloEntrenadores.addElement(rs.getString("nombre") + " " + rs.getString("apellido"));
            }
            rs.close();
            pst.close();

            JComboBox<String> comboEntrenadores = new JComboBox<>(modeloEntrenadores);

            // Campos para nombre y horario
            JTextField nombreClaseField = new JTextField();
            JTextField horarioField = new JTextField();

            JPanel panel = new JPanel(new java.awt.GridLayout(0, 1));
            panel.add(new JLabel("Nombre de la clase:"));
            panel.add(nombreClaseField);
            panel.add(new JLabel("Horario (hh:mm):"));
            panel.add(horarioField);
            panel.add(new JLabel("Entrenador:"));
            panel.add(comboEntrenadores);

            int result = JOptionPane.showConfirmDialog(
                    this, panel, "Crear nueva clase", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE
            );

            if (result == JOptionPane.OK_OPTION) {
                String nombreClase = nombreClaseField.getText();
                String horario = horarioField.getText();
                int entrenadorIndex = comboEntrenadores.getSelectedIndex();

                if (nombreClase.isEmpty() || horario.isEmpty() || entrenadorIndex == -1) {
                    JOptionPane.showMessageDialog(this, "Debes llenar todos los campos y elegir un entrenador.");
                    return;
                }

                int idEntrenador = idsEntrenadores.get(entrenadorIndex);

                // Insertar la nueva clase
                String insertSql = "INSERT INTO clase (nombre, horario, id_entrenador) VALUES (?, ?, ?)";
                PreparedStatement insertPst = con.prepareStatement(insertSql);
                insertPst.setString(1, nombreClase);
                insertPst.setString(2, horario);
                insertPst.setInt(3, idEntrenador);

                int filas = insertPst.executeUpdate();

                if (filas > 0) {
                    JOptionPane.showMessageDialog(this, "Clase registrada correctamente.");
                    // Llama tu método para refrescar la tabla de clases si tienes uno
                    mostrarClases();
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo registrar la clase.");
                }
                insertPst.close();
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al registrar clase: " + e.getMessage());
        }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        int fila = jTable3.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona una clase para eliminar.");
            return;
        }

        // Obtén los datos de la clase seleccionada (ajusta los índices si tu tabla cambia)
        String id = jTable3.getValueAt(fila, 0).toString();
        String nombre = jTable3.getValueAt(fila, 1).toString();
        String horario = jTable3.getValueAt(fila, 2).toString();
        String entrenador = jTable3.getValueAt(fila, 3).toString();

        String mensaje = "¿Estás seguro de eliminar la siguiente clase?\n\n"
                + "ID: " + id
                + "\nNombre: " + nombre
                + "\nHorario: " + horario
                + "\nEntrenador: " + entrenador;

        int opcion = JOptionPane.showConfirmDialog(this, mensaje, "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

        if (opcion == JOptionPane.YES_OPTION) {
            try {
                Conexion connect = Conexion.getInstance();
                Connection con = connect.getConnection();

                String sql = "DELETE FROM clase WHERE id = ?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, id);

                int filas = pst.executeUpdate();

                if (filas > 0) {
                    JOptionPane.showMessageDialog(this, "Clase eliminada correctamente.");
                    mostrarClases(); // Refresca la tabla si tienes este método
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo eliminar la clase.");
                }
                pst.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al eliminar clase: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        int[] filasSeleccionadas = jTable2.getSelectedRows();
        if (filasSeleccionadas.length == 0) {
            JOptionPane.showMessageDialog(this, "Selecciona al menos un cliente.");
            return;
        }

        // Lista de clases en un JComboBox
        java.util.List<Integer> idsClases = new java.util.ArrayList<>();
        javax.swing.DefaultComboBoxModel<String> modeloClases = new javax.swing.DefaultComboBoxModel<>();

        try {
            Conexion connect = Conexion.getInstance();
            Connection con = connect.getConnection();

            String sql = "SELECT id, nombre FROM clase";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                idsClases.add(rs.getInt("id"));
                modeloClases.addElement(rs.getString("nombre"));
            }
            rs.close();
            pst.close();

            JComboBox<String> comboClases = new JComboBox<>(modeloClases);
            int opcionClase = JOptionPane.showConfirmDialog(this, comboClases, "Selecciona la clase", JOptionPane.OK_CANCEL_OPTION);

            if (opcionClase == JOptionPane.OK_OPTION && comboClases.getSelectedIndex() != -1) {
                int idClase = idsClases.get(comboClases.getSelectedIndex());

                String insertSql = "INSERT INTO clase_cliente (id_clase, id_cliente) VALUES (?, ?)";
                PreparedStatement insertPst = con.prepareStatement(insertSql);

                for (int fila : filasSeleccionadas) {
                    String idCliente = jTable2.getValueAt(fila, 0).toString();
                    insertPst.setInt(1, idClase);
                    insertPst.setInt(2, Integer.parseInt(idCliente));
                    insertPst.addBatch();
                }

                int[] resultados = insertPst.executeBatch();
                insertPst.close();

                JOptionPane.showMessageDialog(this, "Clientes asignados correctamente a la clase.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al asignar clientes: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void comboClasesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboClasesMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_comboClasesMouseClicked

    private void comboClasesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboClasesActionPerformed
        int index = comboClases.getSelectedIndex();
        if (index != -1) {
            int idClase = idsClases.get(index);
            mostrarClientesDeClase(idClase);
        }
    }//GEN-LAST:event_comboClasesActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> comboClases;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTableParticipantes;
    // End of variables declaration//GEN-END:variables
}
